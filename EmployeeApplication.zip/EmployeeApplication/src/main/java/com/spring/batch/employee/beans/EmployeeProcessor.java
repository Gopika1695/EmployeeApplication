package com.spring.batch.employee.beans;
import main.EmployeeApplication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.spring.batch.employee.dto.Employee;

public class EmployeeProcessor implements ItemProcessor<Employee, Employee>{
	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeProcessor.class);
	@Override
	public Employee process(Employee employee) {
		Employee emp = new Employee();
		LOGGER.info("Employee name :"+employee.getEmpName());
		LOGGER.info("Employee id:"+employee.getId());
		LOGGER.info("Employee dob::"+employee.getDob());
		LOGGER.info("Employee doj::"+employee.getDoj());
		LOGGER.info("Employee salary::"+employee.getSalary());
		return emp;
	}
}
