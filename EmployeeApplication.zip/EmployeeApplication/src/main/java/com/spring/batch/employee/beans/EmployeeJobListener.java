package com.spring.batch.employee.beans;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.joda.time.DateTime;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;

public class EmployeeJobListener implements JobExecutionListener{
	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeJobListener.class);
	private DateTime startTime, stopTime; 
    private long getTimeInMillis(DateTime start, DateTime stop){
        return stop.getMillis() - start.getMillis();
    }
	@Override
	public void beforeJob(JobExecution jobExecution) {
		startTime = new DateTime();
		LOGGER.info("Employee Job starts at :"+startTime);
	}
	@Override
	public void afterJob(JobExecution jobExecution) {
		stopTime = new DateTime();
        LOGGER.info("Employee Job stops at :"+stopTime);
        LOGGER.info("Total time take in millis :"+getTimeInMillis(startTime , stopTime));
        if(jobExecution.getStatus() == BatchStatus.COMPLETED){
            LOGGER.info("Employee job completed successfully");
        }else if(jobExecution.getStatus() == BatchStatus.FAILED){
            LOGGER.info("Employee job failed with following exceptions ");
            List<Throwable> exceptionList = jobExecution.getAllFailureExceptions();
            for(Throwable th : exceptionList){
                LOGGER.error("exception :" +th.getLocalizedMessage());
            }
        }
		
	}
 
}
