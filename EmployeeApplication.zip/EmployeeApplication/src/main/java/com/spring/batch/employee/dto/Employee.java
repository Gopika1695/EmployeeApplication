package com.spring.batch.employee.dto;
import java.util.Date;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name = "Employee")
public class Employee { 
	private int id;
	 
    private String empName;
 
    private Date dob;
    private Date doj;
    private int salary;
 
    @XmlElement(name = "id")
    public int getId() {
        return id;
    }
 
    public void setId(int id) {
        this.id = id;
    }
    
    @XmlElement(name = "empName")
    public String getEmpName() {
        return empName;
    }
 
    public void setEmpName(String empName) {
        this.empName = empName;
    }
 
    @XmlElement(name = "dob")
    public Date getDob() {
        return dob;
    }
 
    public void setDob(Date dob) {
        this.dob = dob;
    }
    
    @XmlElement(name = "doj")
    public Date getDoj() {
        return doj;
    }
 
    public void setDoj(Date doj) {
        this.doj = doj;
    }
 
    @XmlElement(name = "salary")
    public int getSalary() {
        return salary;
    }
 
    public void setSalary(int salary) {
        this.salary = salary;
    }

	@Override
	public String toString() {
		return "Employee [id=" + id + ", empName=" + empName + ", dob="
				+ dob + ", doj=" + doj + ", salary=" + salary
				+ ", getId()=" + getId() + ", getEmpName()=" + getEmpName()
				+ ", getDob()=" + getDob() + ", getDoj()=" + getDoj()
				+ ", getSalary()=" + getSalary() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}    
}
	 
	   
	 
	
	