package com.spring.batch.employee.beans;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.spring.batch.employee.dto.Employee;

public class EmployeeDetailsItemPreparedStatementSetter implements ItemPreparedStatementSetter<Employee>{
	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeJobListener.class);
	@Override
	public void setValues(Employee item, PreparedStatement ps)
			throws SQLException {
		LOGGER.info("Setting employee details to database");
		ps.setInt(1, item.getId());
		ps.setString(2, item.getEmpName());
		ps.setInt(3, item.getSalary());
		ps.setDate(4, (Date) item.getDob());
		ps.setDate(5, (Date) item.getDoj());
		
	}
}
